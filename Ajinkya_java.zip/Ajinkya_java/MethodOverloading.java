import java.util.*;

class Student
{
	static void displayStudent(String name, int enrol, double marks, int age)	
	{
		System.out.println("\n\n******************\nData of Student 1: ");
		System.out.print("Name: " +name+ "\nEnrolment Number: " +enrol+ "\nPercentage: " +marks+ "\nAge: "+age);
	}
	static void displayStudent(int enrol, String name, double marks, int age)
	{
		System.out.println("\n\n******************\nData of Student 2: ");
		System.out.println("Name: " +name+ "\nEnrolment Number: " +enrol+ "\nPercentage: " +marks+ "\nAge: "+age);
	}
	
}


public class MethodOverloading
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program implements Method Overloading");
		System.out.println("\nEnter the data for Student 1: ");			//getting data for student 1
		System.out.print("Enter name: ");
		String s1Name = sc.nextLine();
		System.out.print("Enter enrolment: ");
		int s1Enrol = sc.nextInt();
		System.out.print("Enter percentage: ");
		double s1Marks = sc.nextDouble();
		System.out.print("Enter age: ");
		int s1Age = sc.nextInt();
		sc.nextLine();
		
		System.out.println("\n\nEnter the data for Student 2: ");
		System.out.print("Enter name: ");					//getting data for student 2
		String s2Name = sc.nextLine();
		System.out.print("Enter enrolment: ");
		int s2Enrol = sc.nextInt();
		System.out.print("Enter percentage: ");
		double s2Marks = sc.nextDouble();
		System.out.print("Enter age: ");
		int s2Age = sc.nextInt();

		Student.displayStudent(s1Name, s1Enrol, s1Marks, s1Age);		//calling method for displaying the data

		Student.displayStudent(s2Enrol, s2Name, s2Marks, s2Age);		//calling same method with change in the order of 
											//the parameters
	}
}