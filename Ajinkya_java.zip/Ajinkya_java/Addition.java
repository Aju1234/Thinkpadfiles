public class Addition
{
	public static void main(String args[])
	{
		int no1= 12, no2= 23;
		int sum= no1 + no2;
		System.out.print("This program will simply add two numbers.");
		System.out.print("\nSum of "+no1+" and "+no2+" is "+sum);
	}
	public static void sub(String args[])
	{
		
	}
}