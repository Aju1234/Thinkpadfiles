import java.util.*;

public class Factorial
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int no, i, respo=0;
		System.out.print("\nThis program will give you the factorial of the given number.");
		do
		{
			long fact = 1;
			System.out.print("\nEnter the number: ");
			no = sc.nextInt();
			for(i=no; i>=1; i--)
			{
				fact = fact*i;
			}
			System.out.print("\nFactorial of the given number is: "+fact);	
			System.out.print("\nDo you want to continue (1/0)? ");
			respo = sc.nextInt();		
		}while(respo == 1);
	}
}