import java.util.*;
	
public class TypeCasting
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This is program is about implicit and explicit type casting.");
		
		System.out.println("Implicit Type Casting:");
		System.out.println("\nWe will perform multiplication of two Integer type numbers");
		System.out.print("\nEnter the first number: ");
		int no1 = sc.nextInt();					//storing no1 in int variable
		System.out.print("Enter the second number: ");
		int no2 = sc.nextInt();					//storing no2 in int variable
		double resMul = no1 * no2;				//storing their product in double type variable
		System.out.println("Multplication of "+no1+" and "+no2+" is "+resMul);

		System.out.println("-------------------------------------------------------");
		System.out.println("\nExplicit Type Casting:");
		System.out.println("We will perform division of two float type numbers.");
		System.out.print("\nEnter the first number: ");
		float no3 = sc.nextFloat();				//storing no3 in float type variable
		System.out.print("Enter the second number: ");
		float no4 = sc.nextFloat();				//storing no3 in float type variable
		int resDiv = (int) (no3 / no4);				//storing the result in int type variable
		System.out.println("Division of "+no3+" and "+no4+" is "+resDiv);
	}		
}
