import java.util.*;

public class VectorHashMapWrapper
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program is about implementation of Vector, Hashmap, Wrapper.");
		int ans = 1;
		do
		{
			System.out.println("\nIn which of the following you want to store your data: ");
			System.out.println("1. Vector \n2. HashMap \n3. Wrapper Class");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine();
			switch(choice)
			{			
				case 1:							
					Vector<String> myVec = new Vector<String>(); 	//declaring vector
					int count = 1;
					System.out.println("\nEnter the list of students: ");
					do
					{
						System.out.print("Enter name: ");
						String name = sc.nextLine();
						myVec.add(name);			//adding data in vector
						System.out.print("\nDo you want add more[0/1]? ");	
						count = sc.nextInt();
						sc.nextLine();			
					}while(count == 1);				//displaying vector in below line
					System.out.print("\n*************\nList of students is as follow: \n" +myVec+ "\n*************");
					System.out.println("\nYou can perform following methods on vector: ");
					System.out.println("1.insertElementAt  | 2.contains | 3.firstElement | 4.lastElement | 5.get | 6.isEmpty | 7.remove | 8.clear");
					int reply = 1;
					do
					{
					System.out.print("\nEnter the task you want to perform: ");
					int task = sc.nextInt();
					sc.nextLine();
					
					switch(task)
					{
						case 1:	
							System.out.print("\nEnter the index at which you want to insert the element: ");
							int index = sc.nextInt();
							sc.nextLine();
							System.out.print("Enter the element you want to insert: ");
							String element = sc.nextLine();
							myVec.insertElementAt(element, index);
							System.out.println("Your vector: "+myVec);
						break;
						
						case 2:
							System.out.print("\nEnter the element you want to check if its there in the vector or not : ");
							String elmt = sc.nextLine();
							if(myVec.contains(elmt))
								System.out.println("Element you entered is PRESENT in the vector.");
							else			
								System.out.println("Element you entered is ABSENT in the vector.");
						break;
		
						case 3:
							System.out.println("\nFirst element of your vector is: "+myVec.firstElement());
						break;

						case 4:
							System.out.println("\nLast element of your vector is: "+myVec.lastElement());
						break;
						
						case 5:
							System.out.print("\nFrom which index you want to get the element: ");
							int idx = sc.nextInt();
							sc.nextLine();
							System.out.println("Element at entered index is: "+myVec.get(idx));
						break;

						case 6:
							if(myVec.isEmpty())
								System.out.println("\nYour vector is empty.");
							else
								System.out.println("\nYour vector is not empty.");			
						break;
			
						case 7:
							System.out.print("\nEnter the index from which you want to remove the element: ");
							int remove = sc.nextInt();
							sc.nextLine();
							myVec.remove(remove);
							System.out.println("Your vector: "+myVec);
						break;
				
						case 8:
							myVec.clear();
							System.out.println("\nYour vector: "+myVec);
						break;
							
					}
					System.out.print("Do you want to continue with vector[0/1]? ");
					reply = sc.nextInt();
					sc.nextLine();
					}while(reply == 1);
						
				break;	
				
				case 2:							// stroing data in hashmap
					HashMap<String, Integer> myMap = new HashMap<String, Integer>();
					System.out.print("\nEnter how many key-value pairs you want in HashMap: ");
     					int no = sc.nextInt();
					sc.nextLine();
       
	        			//getting the values for HashMap
        				for(int i=1; i<=no; i++)			//iterating through hashmap
				        {	
			        		System.out.print("---------------------------------------");
				            	System.out.print("\nEnter the key for key-value pair number " +i+ " : ");
					        String name = sc.nextLine();
					        System.out.print("Enter the value for key-value pair number " +i+ " : ");
					        int enrol = sc.nextInt();
						sc.nextLine();
					        myMap.put(name, enrol);			//putting data in hashmap using add method
				        }
				      							  //displaying size of hashmap
					System.out.println("\n*************\nYour data is as follow: \n" +myMap+ "\n*************");
				break;

				case 3:							//using wrapper class
					System.out.print("\nEnter a byte number: ");
					byte b = sc.nextByte();				//taking byte no
					Byte bObj = b;					//converting byte value to Byte Obj
		
					System.out.print("Enter an interger: ");
					int i = sc.nextInt();				//taking int
					Integer iObj = i;				//converting int value to Integer Obj
				
					System.out.print("Enter the boolean value: ");	
					boolean bool = sc.nextBoolean();		//taking boolean 
					Boolean boolObj = bool;				//converting boolean value to Boolean Obj
					
					System.out.println("\n*************\nAutoboxing - Converting primitive data types to their corresponding object.");
					System.out.println("\nAutoboxing of byte value is: " +bObj);
					System.out.println("Autoboxing of integer value is: " +iObj);
					System.out.println("Autoboxing of boolean value is: " +boolObj+"\n*************");

					System.out.println("\n*************\nUnboxing - Converting objects to their corresponding primitive data types.");
					byte bVal = bObj;				//converting Byte Obj to byte value
					int iVal = iObj;				//converting Integer Obj to int value
					boolean boolVal = boolObj;			//converting Boolean Obj to boolean value
					
					System.out.println("\nUnboxing of byte object is: " +bVal);
					System.out.println("Unboxing of integer object is: " +iVal);
					System.out.println("Unboxing of boolean object is: " +boolVal+"\n*************");
				break;
				default:
					System.out.print("Invalid choice!!");
				}
				System.out.print("\nDo you want to continue with HashMap/Wrapper class[0/1]? ");	
				ans = sc.nextInt();
		}while(ans == 1);
	}
}