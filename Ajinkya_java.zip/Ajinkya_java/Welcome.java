/**
  * This is my first class in java.
  * This is second line comment.
  */
public class Welcome
{
	/**
         * This is main method
         * @param args string array
         */
	public static void main(String args[])
	{
		System.out.println("Welcome to JAVA");
		Welcome w = new Welcome();
		w.demo(10);
	}
	
	/**
	  @return dummy integer
          @param a dummy param
         */
	public int demo(int a)
	{
		return 10;
	}
}
class A
{

}