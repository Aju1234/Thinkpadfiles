import java.util.*;

public class ControlStatements
{
	public static void main(String args[])	
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\nThis program is about Control Statements.");
		int ans = 1;
		do
		{
			System.out.print("------------------------------------------------------------");
			System.out.println("\n-Press 1 to know if your age is appropriate for a party!!");
			System.out.println("-Press 2 to know in which year your JDK was launched.");
			System.out.print("\n Enter your choice: ");
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1:
					System.out.print("\nEnter your age: ");
					int age = sc.nextInt();
					if(age < 12)							//Finding if the age is appropriate or not			
						System.out.println("Kids are not allowed.");
					else if(age > 12 & age <= 19)
						System.out.println("Teenagers are not allowed.");
					else if(age >= 20 & age <= 30)
						System.out.println("Welcome to the party!!");
					else
						System.out.println("Sorry not allowed.");
				break;
				case 2:
					System.out.print("------------------------------------------------------------");
					System.out.println("\nNOTE- JDK 1.2 to JDK 1.7 are depricated so they are not considered in this program.");
					System.out.print("\nEnter your JDK version (in whole number): ");
					int version = sc.nextInt();
					switch(version)		//Using switch case to get to the right version
					{
						case 8:
							System.out.println("JDK 1.8 was launched in 2014 and is a LTS(Long Term Supported) version too.");
						break;
						case 9:
							System.out.println("JDK 1.9 was launched in 2017.");
						break;
						case 10:
							System.out.println("JDK 10 was launched in March 2018.");
						break;
						case 11:
							System.out.println("JDK 11 was launched in September 2018 and is a LTS(Long Term Supported) version too.");
						break;
						case 12:
							System.out.println("JDK 12 was launched in March 2019.");
						break;
						case 13:
							System.out.println("JDK 13 was launched in September 2019.");
						break;
						case 14:
							System.out.println("JDK 14 was launched in March 2020.");
						break;
						case 15:
							System.out.println("JDK 15 was launched in September 2020.");
						break;
						case 16:
							System.out.println("JDK 16 was launched in March 2021.");
						break;
						case 17:
							System.out.println("JDK 17 was launched in September 2021 and is a LTS(Long Term Supported) version too.");
						break;
						default:
							System.out.println("Either depricated or invalid jdk version.");
					}
				break;
				default:
					System.out.println("Invalid choice");	
				
			}
			System.out.print("\n\nDo you want to continue(0/1)? ");
			ans = sc.nextInt();
		}while(ans == 1);
	}

}