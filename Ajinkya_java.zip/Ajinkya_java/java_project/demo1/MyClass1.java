package demo1;

public class MyClass1
{
	private int no;
	private int getNo()
	{
		return no;
	}
	public int getNumber()
	{
		return getNo();
	}
}
