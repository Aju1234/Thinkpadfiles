public class MyArray
{
	public static void main(String args[])
	{
		int a =10;
		int arr[] = new int[a];
	} 
}