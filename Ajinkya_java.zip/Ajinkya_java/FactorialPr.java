import java.util.*;

public class FactorialPr
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will find the factorial of the entered number.");
		int ans = 1;
		do
		{
			System.out.print("\nEnter the number: ");
			int num = sc.nextInt();
			int fact = 1;
			for(int i = 1; i<=num; i++)
				fact = fact * i;	
			System.out.print("\nFactorial of "+num+" is "+fact);
			System.out.print("\nDo you want to continue(0/1)? ");
			ans = sc.nextInt();
		}while(ans == 1);
	}
}