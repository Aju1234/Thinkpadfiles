package demo2;
import demo1.MyClass1;

public class MyClass2 extends MyClass1
{
	public static void main(String args[])
	{
		System.out.println(new MyClass1().getNumber());
	}
}
