import java.util.*;

public class ArrInsertion
{
	public static void main(String args[])
	{
		System.out.print("\n This program will insert a new element in an array as per user's requirement.");
		Scanner sc = new Scanner(System.in);
		int length = 5;
		int arr[] = new int[length];
		System.out.print("\n Enter the size of array [less than " + length + " ]: ");
		int size = sc.nextInt();
		
		for(int i=0; i<size; i++)
		{
			System.out.print("\n Enter the value for index "+i+": ");
			arr[i] = sc.nextInt();
		}
		
		System.out.print("\n Your array is: ");
		for(int i=0; i<size; i++)
		{
			System.out.print(" "+arr[i]);
		}

		int respo = 0;
		do
		{	
			if (size >= length)
			{
				respo = 0;
				System.out.print("\n Array is full. can't insert new elements!!!: ");
			}
			else
			{
				System.out.print("\n Enter the number you want to insert in the array: ");
				int no = sc.nextInt();		
				System.out.print("\n Select the place where you want to insert the given number: ");
				System.out.print("\n 1. At the beggining.\n 2. At a specific index.\n 3. At the end.");
				System.out.print("\n Enter your choice: ");
				int task = sc.nextInt();
				switch(task)
				{
					case 1:
						for(int i=size; i>0; i--)
							arr[i] = arr[i-1];
						arr[0] = no;
						size++;
						System.out.print("\n Your new array is: ");
						for(int i=0; i<size; i++)
						{
							System.out.print(" " + arr[i]);
						}
						break;	

					case 2:
						System.out.print("\n Enter the index where you want to insert the number: ");					
						int index = sc.nextInt();
		                   		for(int i = size; i>index; i--)
							arr[i] = arr[i-1];
						arr[index] = no;
						size++;
						System.out.print("\n Your new array is: ");
						for(int i=0; i<size; i++)
						{
							System.out.print(" " + arr[i]);
						}
						break;	
	
					case 3:	
						arr[size] = no;
						size++;
						System.out.print("\n Your new array is: ");
						for(int i=0; i<size; i++)
						{
							System.out.print(" " + arr[i]);
						}
						break;
					default:
						System.out.print("\n Invalid choice.");	
	
				}
				System.out.print("\n Do you want to continue(1/0)? ");
				respo = sc.nextInt();
			}
		}while(respo == 1);
	}
}
