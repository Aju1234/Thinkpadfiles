class Rational
{
	double num, den;
	Rational()
	{}
	Rational(double num,double den)
	{
		this.num = num;
		this.den = den;
	}
	void add(Rational r1, Rational r2)
	{
		double num = (r1.num * r2.den) + (r1.den * r2.num);
		double den = r1.den * r2.den;
		Rational res = new Rational(num, den);
		res.display();
	}
	void multi(Rational r1, Rational r2)
	{
		double num = r1.num *  r2.num;
		double den = r1.den * r2.den;
		Rational res = new Rational(num, den);
		res.display();
	}
	void display()
	{
		System.out.println(num+ " / " +den);
	}
}
public class RationalADT
{
	public static void main(String arg[])
	{
		Rational r1 = new Rational(3, 5);
		Rational r2 = new Rational(4, 7);

		Rational temp = new Rational();
		temp.add(r1, r2);
		temp.multi(r1, r2);
	}
}