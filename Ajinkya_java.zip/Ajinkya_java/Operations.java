import java.util.*;

public class NestingMethods
{
		public void add(int a, int b)
		{
			System.out.println("\nAddition of " +a+ " and " +b+ " is " +(a+b));
			sub(a, b);
			System.out.println("Flow control is passed back to the main method.");
		}
		
		public void sub(int i, int j)
		{
			System.out.println("\nSubtraction of " +i+ " and "+j+ " is "+(i-j));
			mul(i,j);
		}
		public void mul(int x, int y)
		{
			System.out.println("\nMultiplication of " +x+ " and "+y+ " is "+(x*y));
		}
		
	public static void main(String args[])
	{
	
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will do nesting of methods.");
		System.out.println("Enter two numbwrs to perform basic operations.");
		System.out.print("\nEnter the first number: ");
		int no1 = sc.nextInt();
		System.out.print("Enter the second number: ");
		int no2 = sc.nextInt();
		NestingMethods op = new NestingMethods();
		op.add(no1, no2);
		System.out.println("Back in main method");
		
	}	
}
