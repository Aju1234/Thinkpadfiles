import java.util.*;

class Person
{
	int age;
	String name;
	Scanner sc = new Scanner(System.in);
	public void personDetails()
	{
		System.out.print("\nEnter the name: ");
		name = sc.nextLine();
		System.out.print("Enter the age: ");
		age = sc.nextInt();
	}
	public void displayPerson()
	{
		System.out.println("\n*****************\nDisplaying details: ");
		System.out.println("\nName: " +name+ "\nAge: "+age);
	}
}
class Teacher extends Person
{
	int salary, exp;
	Scanner sc = new Scanner(System.in);
	public void teacherDetails()
	{
		System.out.println("Enter the following details for a teacher: ");
		personDetails();
		System.out.print("Enter the salary: ");
		salary = sc.nextInt();
		System.out.print("Enter experience: ");
		exp = sc.nextInt();
	}
	public void displayTeacher()
	{
		displayPerson();
		System.out.println("Salary: " +salary+ "\nExpereince: "+exp);
	}
}

public class SingleInheritance
{
	public static void main(String arg[])
	{		
		Teacher tObj = new Teacher();
		tObj.teacherDetails();
		tObj.displayTeacher();
		
	}
}
