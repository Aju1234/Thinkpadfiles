import java.util.*;

public class ArrMedian
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int  i, size, mid, respo=0;
		int arr[];
		System.out.print("\n This program will find the median of the array.");
		do
		{
			System.out.print("\n------------------------------------------------");
			System.out.print("\n Enter the size of array: ");
			size = sc.nextInt();
			arr = new int[size];
			System.out.print("\n Please enter the number in ascending order.");
			for(i=0; i<size;i++)
			{
				System.out.print("\n Enter number for index " + i +" :");
				arr[i] = sc.nextInt();
			}
			System.out.print("\n Your array is: ");
			for(i=0; i<size;i++)
			{
				System.out.print(" "+arr[i]);	
			}
			mid = size/2;
			if(size%2 == 0)
			{
				float even= (float)(arr[mid-1] + arr[mid]) / 2;
				System.out.print("\n Median of the array is :" +even);
			}	
			else
				System.out.print("\n Median of the array is: " +arr[mid]);
			System.out.print("\n------------------------------------------------");
			System.out.print("\n Do you want to continue(1/0)? ");
			respo = sc.nextInt();
		}while(respo == 1);
	}
}