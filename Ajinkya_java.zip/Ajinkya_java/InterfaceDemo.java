import java.util.*;
	
interface MyInterface
{
	void info();
	void display();
}

class Person implements MyInterface
{
	String name, gender;
	int age;
	public void info()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your name: ");
		name = sc.nextLine();
		System.out.print("Enter your gender: ");
		gender = sc.nextLine();
		System.out.print("Enter your age: ");
		age = sc.nextInt();
	}
	
	public void display()
	{
		System.out.println("\n\nDisplaying details: ");
		System.out.println("Name: " +name+ "\nGender: " +gender+ "\nAge: "+age);
	}
}

public class InterfaceDemo
{
	public static void main(String args[])
	{
		Person myObj = new Person();
		myObj.info();
		myObj.display();
	}
}