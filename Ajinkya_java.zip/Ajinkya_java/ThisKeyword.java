//This program is about 'this' keyword.
class Student
{
	String name;
	int rn;
	Student(String name, int rn)
	{
		this.name = name;
		this.rn = rn;
		dispStudent();
	}	
	void dispStudent()
	{
	System.out.println("Name: " +name+ "   Enrollment No: "+ rn);
	}
}
public class ThisKeyword
{
	public static void main(String args[])
	{
		Student s1 = new Student("Ajinkya Tambe", 1906129);
		Student s2 = new Student("Ajay Dave", 1768976);
	}
}