import java.util.*;

interface Person
{
	void personDetails();
	void displayPerson();
}
interface Education
{
	void eduDetails();
	void displayEdu();
}
interface Post
{
	void postDetails();
	void displayPost();
}

class Employee implements Person, Education, Post
{
	Scanner sc = new Scanner(System.in);
	String name, org, post, qual;
	float salary;
	int id, noProj;
	public void personDetails()
	{
		System.out.print("Enter your name: ");
		name = sc.nextLine();
		System.out.print("Enter your ID: ");	
		id= sc.nextInt();
		sc.nextLine();
	}
	
	public void eduDetails()
	{
		System.out.print("Enter your qualification: ");
		qual = sc.nextLine();
		System.out.print("Enter number of projects you have done: ");
		noProj = sc.nextInt();
		sc.nextLine();
	}

	public void postDetails()
	{
		System.out.print("Enter the name of organizatoin you're working in: ");
		org = sc.nextLine();
		System.out.print("Enter the post you work on: ");
		post = sc.nextLine();
		System.out.print("Enter your salary: ");	
		salary = sc.nextFloat();
		sc.nextLine();	
	}

	public void displayPerson()	
	{
		System.out.println("\n\nDisplay details: ");
		System.out.println("Name: " +name+ "\nID: " +id);
	}
	
	public void displayEdu()
	{
		System.out.println("Qualification: " +qual+ "\nNo of projects done: " +noProj);	
	}
	
	public void displayPost()
	{
		System.out.println("Organization: " +org+ "\nPost: " +post+ "\nSalary: " +salary);
	}	
}

class GetDetails extends Employee 
{
	void getDetails()
	{
		personDetails();
		eduDetails();
		postDetails();
	}
}

class DisplayDetails extends GetDetails 
{
	void displayDetails()
	{
		displayPerson();
		displayEdu();
		displayPost();
	}
}
public class MultipleInterface
{
	public static void main(String args[])
	{
		//GetDetails myGetObj = new GetDetails();
		DisplayDetails myDispObj = new DisplayDetails();
		myDispObj.getDetails();
		myDispObj.displayDetails();	
	}
}