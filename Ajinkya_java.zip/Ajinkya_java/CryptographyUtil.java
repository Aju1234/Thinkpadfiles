import java.security.*;
import javax.crypto.Cipher;

class AsymmetricKeyCryptography
{
    public String encrypt(String algorithm, byte[] publicKey, String message)
            throws Exception {

        PublicKey key = KeyFactory.getInstance(algorithm)
                .generatePublic(new X509EncodedKeySpec(publicKey));

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] encryptedBytes = cipher.doFinal(message.getBytes());

        return new String(encryptedBytes);
    }

    public String decrypt(String algorithm, byte[] privateKey, String inputData)
            throws Exception {

        PrivateKey key = KeyFactory.getInstance(algorithm)
                .generatePrivate(new PKCS8EncodedKeySpec(privateKey));

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key);

        byte[] decryptedBytes = cipher.doFinal(inputData.getBytes());

        return new String(decryptedBytes);
    }

    public static KeyPair generateKeyPair(String algorithm)
            throws NoSuchAlgorithmException, NoSuchProviderException {

        KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algorithm);

        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");

        // 512 is keysize
        keyGen.initialize(512, random);

        KeyPair generateKeyPair = keyGen.generateKeyPair();
        return generateKeyPair;
    }

}


public class AsymmetricKeyCryptographyDemo
{
    public static void main(String[] args) throws Exception
    {
	String algorithm = "RSA";

	AsymmetricKeyCryptography crypto = new AsymmetricKeyCryptography();
        KeyPair generateKeyPair = crypto.generateKeyPair(algorithm);

        byte[] publicKey = generateKeyPair.getPublic().getEncoded();
        byte[] privateKey = generateKeyPair.getPrivate().getEncoded();

	Scanner sc = new Scanner(System.in);
	char ans = 'y';
	do
	{
		System.out.println("Enter message: ");
		String message = sc.nextLine();
		String encryptedMessage = crypto.encrypt(algorithm, publicKey, message);
		System.out.println("Encrypted Message: " + encryptedMessage);
	        String decryptedMessage = crypto.decrypt(algorithm, privateKey, encryptedMessage);
	        System.out.println("Decryptrd Message: " + decryptedMessage));
		
		System.out.println("Do you want to continue[y/n]? ");
		ans = sc.next().charAt(0);
	}while(ans='y');
    }
}
