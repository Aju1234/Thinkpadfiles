import java.util.*;
	
public class Loops
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This is program is to demonstrate use of Loops.");
		int ans = 1;
		do
		{
			System.out.print("------------------------------------------------------------");
			System.out.println("\n-Press 1 to find if the number is perfect square or not. (using for loop)");
			System.out.println("-Press 2 to get the dodging of entered number (using while loop).");
			System.out.print("\nEnter your choice: ");
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1:			//for perfect square
					System.out.print("\nEnter the number: ");
					int num = sc.nextInt();
					boolean flag = false;
					for(int i=1; i<=num/2; i++)
					{
						if(num == i*i)		//checking if num is perfect square
						{
							flag = true;
							break;
						}
					}
					if(flag)
						System.out.println(num+ " is a perfect square.");
					else
						System.out.println(num+ " is not a perfect square.");
				break;
				case 2:			//for dodging
					System.out.print("\nEnter the number to get its dodging: ");
					int no = sc.nextInt();
					int i = 1;
					while(i <= 10)
					{
						System.out.print("\n"+no+" x "+i+" = "+no*i);		//printing the dodging
						i++;
					}
				break;
				default:
					System.out.println("Invalid choice.");
			}
			System.out.print("\nDo you want to continue(0/1)? ");
			ans = sc.nextInt();
		}while(ans == 1);

	}
	
}

//for
//while
//do while