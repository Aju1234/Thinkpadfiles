import java.security.*;
import java.security.spec.*;
import javax.crypto.Cipher;

import java.util.*;

class AsymmetricKeyCryptography
{
    public byte[] encrypt(String algorithm, byte[] publicKey, byte[] message)
            throws Exception {

        PublicKey key = KeyFactory.getInstance(algorithm).generatePublic(new X509EncodedKeySpec(publicKey));

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] encryptedBytes = cipher.doFinal(message);

        return encryptedBytes;
    }

    public String decrypt(String algorithm, byte[] privateKey, byte[] message)
            throws Exception {

        PrivateKey key = KeyFactory.getInstance(algorithm)
                .generatePrivate(new PKCS8EncodedKeySpec(privateKey));

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key);

        byte[] decryptedBytes = cipher.doFinal(message);

        return new String(decryptedBytes);
    }

    public static KeyPair generateKeyPair(String algorithm)
            throws NoSuchAlgorithmException, NoSuchProviderException {

        KeyPairGenerator keyGen = KeyPairGenerator.getInstance(algorithm);

        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");

        // 512 is keysize
        keyGen.initialize(512, random);

        KeyPair generateKeyPair = keyGen.generateKeyPair();
        return generateKeyPair;
    }

}


public class AsymmetricKeyCryptographyDemo
{
    public static void main(String[] args) throws Exception
    {
	String algorithm = "RSA";

	AsymmetricKeyCrypt

ography crypto = new AsymmetricKeyCryptography();
        KeyPair generateKeyPair = crypto.generateKeyPair(algorithm);

        byte[] publicKey = generateKeyPair.getPublic().getEncoded();
        byte[] privateKey = generateKeyPair.getPrivate().getEncoded();

	Scanner sc = new Scanner(System.in);
	char ans = 'y';
	do
	{
		System.out.println();
		System.out.print("Enter message: ");
		String message = sc.nextLine();
		byte[] encryptedMessage = crypto.encrypt(algorithm, publicKey, message.getBytes());
		System.out.println("Encrypted Message: " + new String(encryptedMessage));
	        String decryptedMessage = crypto.decrypt(algorithm, privateKey, encryptedMessage);
	        System.out.println("Decryptrd Message: " + decryptedMessage);
		
		System.out.print("Do you want to continue[y/n]? ");
		ans = sc.nextLine().charAt(0);
	}while(ans=='y');
    }
}
