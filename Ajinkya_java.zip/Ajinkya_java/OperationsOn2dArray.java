import java.util.*;

public class OperationsOn2dArray
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\nThis program is about Matrix Operations.");
		System.out.print("\nEnter number of rows and columns your matrices should have: ");
		int size = sc.nextInt();
		System.out.println("\nEnter the value for your first matrix: ");		//taking first matrix
		int arr1[][] = new int[size][size];
		for(int i = 0; i < size; i++)							//for loop for columns
		{
			for(int j = 0; j < size; j++)						//for loop for rows
			{
				System.out.print("Enter the element for index ["+i+"]["+j+"] : ");
				arr1[i][j] = sc.nextInt();					//accepting the element
			}
		}
		System.out.println("\nEnter the value for your second matrix: ");		//taking second matrix
		int arr2[][] = new int[size][size];
		for(int p = 0; p < size; p++)							//for loop for columns
		{
			for(int q = 0; q < size; q++)						//for loop for rows
			{
				System.out.print("Enter the element for index ["+p+"]["+q+"] : ");
				arr2[p][q] = sc.nextInt();					//accepting the element
			}		
		}


		System.out.println("\nYour first matrix is: ");					//displaying the first matrix
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				System.out.print(arr1[i][j]+ " ");
			}
			System.out.print("\n");
		}
		System.out.println("\nYour second matrix is: ");				//displaying the second matrix
		for(int p = 0; p < size; p++)
		{
			for(int q = 0; q < size; q++)
			{
				System.out.print(arr2[p][q]+ " ");
			}
			System.out.print("\n");
		}

		int ans = 1;
		do
		{	
			System.out.print("\nWhich operation you want to perform: ");
			System.out.print("\n1. Addition of two matrices. \n2. Substraction of two matrices. \n3. Multiplication of two matrices \n4. Transpose of matrix.");
			System.out.print("\nEnter your choice: ");
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1:								//addition of two matirx
					System.out.println("\nFinal matrix after addition of given matrices is:");
					int resAdd[][] = new int[size][size];
					for(int i = 0; i < size; i++)
					{
						for(int j = 0; j < size; j++)
						{
							System.out.print((resAdd[i][j] = arr1[i][j] + arr2[i][j]) +" ");
						}
						System.out.print("\n");
					}
				break;

				case 2:								//subtraction of two matrix
					System.out.println("\nFinal matrix after substraction of given matrices is:");
					int resSub[][] = new int[size][size];
					for(int i = 0; i < size; i++)
					{
						for(int j = 0; j < size; j++)
						{
							System.out.print((resSub[i][j] = arr1[i][j] - arr2[i][j]) +" ");
						}
						System.out.print("\n");
					}
				break;
				
				case 3:								//multiplication of two matrix
					System.out.println("\nFinal matrix after multiplication of given matrices is:");
					int resMul[][] = new int[size][size];
					for(int i = 0; i < size; i++)
					{
						for(int j = 0; j < size; j++)
						{
							for(int a = 0; a < size; a++)
							{
								resMul[i][j] = resMul[i][j] + (arr1[i][a] * arr2[a][j]);
								
							}
							System.out.print(resMul[i][j] +" ");
						}
						System.out.print("\n");
					}
				break;
		
				case 4:							//transpose of first matrix
				System.out.println("\nTranspose of first matrix is: ");
				int arrTrans[][] = new int[size][size];
				for(int i = 0; i < size; i++)
					{
						for(int j = 0; j < size; j++)
						{
							System.out.print((arrTrans[i][j] = arr1[j][i])+" ");
						}
						System.out.print("\n");
					}
				
			}
			System.out.print("\nDo you want to continue[1/0]? ");
			ans = sc.nextInt();
		}while(ans == 1);
	}
}