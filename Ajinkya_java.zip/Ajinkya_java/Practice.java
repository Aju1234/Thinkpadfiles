class Marks
{	
	public void subjectMarks()
	{
		int subject1 = 80, subject2 = 90;
		System.out.println("Marks for subject 1 is: "+ subject1);
		System.out.println("Marks for subject 2 is: "+ subject2);
	}
	public void totalMarks()
	{
		int total = subject1 + subject2;
		System.out.println("Total marks: "+ total);
	}
	public void avgMarks()
	{
		float avg = (total) / 2;
		System.out.println("Average marks: "+ avg);
		if(avg >= 90.0)
			System.out.println("Grade: A");
		else
			System.out.println("Grade: B");
	}
}
public class Assignment1
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Press 1 to see Subject marks.");
		System.out.println("2. Press 2 to see total marks.");
		System.out.println("3. Press 3 to see average marks and grade.");
		System.out.println("Enter your choice: ");
		int respo = sc.nextInt();
		Marks obj = new Marks();
		switch(respo)
		{
			case 1:
				obj.subjectMarks();
			break;

			case 2:
				obj.totalMarks();
			break;

			case 3:
				obj.avgMarks();
			break;
	
			default:
				System.out.println("Incorrect choice.");
		}
		
	}
}