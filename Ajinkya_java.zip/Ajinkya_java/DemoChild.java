class Demo
{
	Demo()
	{
		display();
	}
	private void display()
	{
		System.out.print("Hello there");
	}
}

class DemoChild extends Demo
{
	public static void main(String args[])
	{
		Demo d = new Demo();
	}
}