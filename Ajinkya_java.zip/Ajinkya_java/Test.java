public class Test
{
	public static void main(String aju[])
	{
		float f = ((float)10.7);
		System.out.println("Value of the floating point number is " + f );
		int a = -19;
		System.out.println("Value of a before using ~: " +a);
		a = ~a;
		System.out.println("Value of a after using ~: " +a);
		
	}

}