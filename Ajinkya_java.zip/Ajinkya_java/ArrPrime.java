import java.util.*;
	
public class ArrPrime
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int arr[], i, size, respo=0;
		boolean flag;
		System.out.print("\n This program will find all the prime numbers from the given array.");
		do
		{
			flag = true;
			System.out.print("\n Enter the size of array: ");
			size = sc.nextInt();
			arr = new int[size];
			for(i=0; i<size; i++)
			{
				System.out.print("\n Enter the value for index "+i+" : ");
				arr[i] = sc.nextInt();	
			}
			System.out.print("\n Your array is: ");
			for(i=0; i<size; i++)
				System.out.print(" " +arr[i]);	
			System.out.print("\n Prime number(s) from the given array is/are: ");
			for(i=0; i<size; i++)
			{
				flag = true;
				if(arr[i] == 1)
				{
					flag = false;
				}
				else
				{
					for(int j=2; j<=arr[i]/2; j++)
					{	
						if(arr[i]%j == 0)
						{
							flag = false;
							//System.out.print(arr[i]+" ");
						}
					}
				}
				if(flag)
					System.out.print(arr[i]+" ");
			}
			System.out.print("\n Do you want to continue(1/0)? ");
			respo = sc.nextInt();
		}while(respo == 1);
	}
}
