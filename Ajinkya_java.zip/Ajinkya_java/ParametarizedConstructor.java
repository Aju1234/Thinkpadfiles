import java.util.*;
class Employee
{
	String name;	
	int id;
	int salary;
	Employee(String name, int id, int salary)	//Defining the contructor explicitly which will hide/disappear the default constuctor
	{
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
	void display()				//To display the data
	{
		System.out.print("\n-----------------\n Employee Details: ");
		System.out.println("\n\n Id-> " +id+ "\n Name-> "+name+ "\n Salary-> "+salary);
	}
}
public class ParametarizedConstructor
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("\nEnter Employee name: ");
		String name = sc.nextLine();	
		System.out.print("Enter Employee ID: ");
		int id = sc.nextInt();
		System.out.print("Enter Employee salary: ");
		int salary = sc.nextInt();		
		Employee e1 = new Employee(name, id, salary);		//Calling the constructor at the time of obj creation
		e1.display();	
	}
}