import java.util.*;

public class Array1D
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of subject: ");
		int n = sc.nextInt();
		String subject[] = new String[n] ;
		for(int i=0; i<subject.length; i++)
		{
			System.out.print("Enter the name of subject "+(i+1)+" : ");		//taking the subjects
			subject[i] = sc.next();
		}
		System.out.print("\nSubjects you have are as follow: ");
		for(int i=0; i<subject.length; i++)
		{
			System.out.print("\n\nSubject "+(i+1)+" -> "+subject[i]);		//displaying the array
		}
	}
}