import java.util.*;

class GP
{
	String status;
	void getstatus()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("\nEnter your status: ");
		status = sc.nextLine();
	}
}

class Parent extends GP{}
class Child1 extends Parent{}
class Child2 extends Parent{}

public class Hybrid
{
	public static void main(String args[])
	{
		GP myObjGp = new GP();
		myObjGp.getstatus();
		Parent myObjP = new Parent();
		myObjP.getstatus();
		Child1 myObj1 = new Child1();
		myObj1.getstatus();
		Child2 myObj2 = new Child2();
		myObj2.getstatus();
	}
}