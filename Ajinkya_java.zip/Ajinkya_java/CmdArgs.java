public class CmdArgs
{
	public static void main(String args[])
	{
		System.out.print("\nIn this program we are passing args from cmd prompt to main method while running the program");
		System.out.println("\n\nDetained Students List: ");
		if(args.length > 0)
		{
			for(int i = 0; i < args.length; i++)
				System.out.println((i+1)+". "+args[i]);
		}
		else
			System.out.print("List is empty!");
	}
}