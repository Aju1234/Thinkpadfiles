//import java.util.*;

class Employee
{
	String name;
	int id, salary;
	//Employee(){};		We can also write default/no-args constructor explicitly
	void displayEmployee()
	{
		System.out.println("\nName of Employee: "+name+"\nEmployee ID: "+id+"\nSalary of Employee: "+salary);
	} 
}

public class DefaultConstructor
{
	public static void main(String args[])
	{
		Employee e1 = new Employee(); 		//As we have not defined any constructor in Employee class, 
							//default constructor will be called implicitly		
		e1.displayEmployee();
	}
}