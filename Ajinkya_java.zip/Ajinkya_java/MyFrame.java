import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyFrame extends WindowAdapter implements ActionListener
{
	static JFrame jf;
	public static void main(String args[])
	{
		MyFrame mf = new MyFrame();
		jf = new JFrame();
		
		MyPanel cp = new MyPanel();
		
		//Container cp = jf.getContentPane();
		cp.setBackground(Color.yellow);
		cp.setLayout(null);
		/*JButton jb = new JButton("Move");
		jb.setLocation(150, 150);
		jb.setSize(70, 20);
		jb.addActionListener(mf);
		cp.add(jb);*/
		
		jf.addWindowListener(mf);

		jf.setContentPane(cp);
		jf.setSize(600, 500);
		jf.setVisible(true);

	}
	public void windowClosing(WindowEvent we)
	{
		System.exit(0);
	}

	public void actionPerformed(ActionEvent ae)
	{
		jf.setLocation(100, 100);
	}
		
}

class MyPanel extends JPanel
{
	protected void paintComponent(Graphics g) {
               super.paintComponent(g);
               //g.drawString("Hello World", 50, 50);
		g.setColor(Color.red);
		g.fillOval(300, 300, 50, 100);
		g.drawLine(325, 400, 325, 450);

		g.fillOval(375, 300, 50, 100);
		g.drawLine(400, 400, 400, 450);
	
		g.fillOval(450, 300, 50, 100);
		g.drawLine(475, 400, 475, 450);

		
		g.drawLine(0, 100, 75, 100);
		g.drawLine(50, 80, 75, 100);
		g.drawLine(50, 120, 75, 100);
        }
}