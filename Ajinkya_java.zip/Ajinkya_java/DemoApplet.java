/*<applet code="DemoApplet" height="600" width="1200"></applet>*/
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class DemoApplet extends Applet implements MouseListener, Runnable
{
	boolean flag = true;
	int x = 0, y = 350, dx = 1, dy = 2;
	public void init()
	{
		//Container cp = getContentPane();
		addMouseListener(this);
		setBackground(Color.yellow);
		//setLocation(200, 200);
		Thread t = new Thread(this);
		t.start();
	}
	public void paint(Graphics g)
	{
		g.setColor(Color.red);
		g.fillOval(x, y, 100, 100);
		if (flag)
		{
			
			x+=dx;
			y+=dy;
			if(x <= 0 || x >= 1100)
				dx = -dx;
			if(y <= 0 || y >= 500)
				dy = -dy;	
		}
	}

	public void run()
	{
		while(true)
		{
			try
			{
				Thread.sleep(2); 
			}
			catch(InterruptedException e)
			{
			}

			repaint();
		}
	}
	
	public void mouseClicked(MouseEvent me)
	{
		flag = !flag;
	}

	public void mouseReleased(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	
}