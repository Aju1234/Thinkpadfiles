import java.util.*;
public class PerfectSquare
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int no, i;
		int respo = 0;
		System.out.print("This program will tell if the entered number is perfect square or not.");
		do
		{
			System.out.print("\nEnter the number: ");
			no = sc.nextInt();
			boolean flag = false;
			for(i=1; i<=no/2; i++)
			{
				if(no == i*i)
				{
					flag=true;
					break;			
				}
			}
			if(flag)
				System.out.print("\n"+no+" is a perfect square.");
			else
				System.out.print("\n"+no+" is not a perfect square.");
			System.out.print("\nDo you want to continue (0/1)? ");
			respo = sc.nextInt();
		}while(respo == 1);		
	}
}