import java.util.*;
public class ArithmeticOp
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int no1, no2, task, respo=0;
		System.out.println("\nArithmetic Operations:");
		do
		{
			System.out.print("\n 1. Addition\n 2. Substraction\n 3. Multiplication\n 4. Division");
			System.out.print("\nEnter the task you want to perform: ");
			task = sc.nextInt();
			switch(task)
			{
				case 1:
					System.out.print("\nEnter your first number: ");
					no1= sc.nextInt();
					System.out.print("\nEnter your second number: ");
					no2= sc.nextInt();
					//int sum = no1 + no2;
					System.out.print("\nAddition of " +no1+ " and " +no2+ " is: " + (no1+no2));
					break;
				case 2:
					System.out.print("\nEnter your first number: ");
					no1= sc.nextInt();
					System.out.print("\nEnter your second number: ");
					no2= sc.nextInt();
					int sub= no1 - no2;
					System.out.print("\nSubtraction of " +no1+ " and " +no2+ " is: " + sub);
					break;
				case 3:
					System.out.print("\nEnter your first number: ");
					no1= sc.nextInt();
					System.out.print("\nEnter your second number: ");
					no2= sc.nextInt();
					int mul= no1 * no2;
					System.out.print("\nSubtraction of " +no1+ " and " +no2+ " is: " + mul);
					break;
				case 4:
					System.out.print("\nEnter your first number: ");
					float div_no= sc.nextInt();
					System.out.print("\nEnter your second number: ");
					no2= sc.nextInt();
					float div= div_no / no2;
					System.out.print("\nDivision of " +div_no+ " and " +no2+ " is: " + div);
					break;
				default:
					System.out.print("\nInvalid choice.");

			}System.out.print("\nDo you want to continue(1/0)? ");
			respo= sc.nextInt();			
		}while(respo == 1);
	}
	 
}