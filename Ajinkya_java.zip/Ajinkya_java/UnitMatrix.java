import java.util.*;

public class UnitMatrix
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will find out if the 2D Array which you entered is Unit Matrix or not.");
		System.out.print("Enter number of rows: ");
		int n = sc.nextInt();
		int arr[][] = new int[n][n];
		for(int i=0; i<n; i++)				//taking the array the matrix from the user
		{
			for(int j=0; j<n; j++)
			{
				System.out.print("Enter the number for arr[" +i+ "][" +j+ "] : ");
				arr[i][j] = sc.nextInt();
			}
		}
		System.out.println("\nYour Matrix is: ");	
		for(int i=0; i<n; i++)				//displaying the matrix 
		{
			for(int j=0; j<n; j++)
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		boolean flag = true;
		aa:for(int i=0; i<n; i++)				//checking if the matrix entered is unit or not
		{
			for(int j=0; j<n; j++)
			{
				if(i==j & arr[i][j]!=1)
				{
					System.out.println("here");
					flag = false;
					break aa;
				}
				else
				{
					if(arr[i][j] != 0)
					{
						System.out.println("here else");
						flag = false;
						break aa;
					}
				}
			}
		}
		if(flag == true)
			System.out.println("This is an Unit Matrix.");
		else
			System.out.println("This is not an Unit Matrix");
	}	
}