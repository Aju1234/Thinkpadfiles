public class Add
{
	public static void main(String args[])
	{
		int no1 = 30, no2 = 40;
		int ans = no1 + no2;
		System.out.println("Addition of "+ no1 + " and "+ no2 +" is "+ ans);
	}
}