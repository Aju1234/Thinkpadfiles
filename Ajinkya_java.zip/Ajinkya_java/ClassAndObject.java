import java.util.*;
class Car
{
	String name, colour;
	long prize;
	String fuelType;
	void display()
	{
		System.out.println("------------------------------");
		System.out.println("Name of the car  : " +name);
		System.out.println("Prize of the car : " +prize);
		System.out.println("Colour of the car: " +colour);
		System.out.println("Fuel type        : " +fuelType);
	}
}
public class ClassAndObject
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Car model1 = new Car();
		System.out.print("Enter the name of the car: " );
		model1.name = sc.nextLine();
		System.out.print("Enter the prize of the car: " );
		model1.prize = sc.nextLong();
		sc.nextLine();
		System.out.print("Enter the colour of the car: " );
		model1.colour = sc.nextLine();
		System.out.print("Enter the type of fuel car takes: " );
		model1.fuelType = sc.nextLine();
		model1.display();
	}
}