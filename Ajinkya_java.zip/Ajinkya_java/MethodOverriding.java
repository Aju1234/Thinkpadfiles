import java.util.*;

class Student1
{
	void displayStudent(String name, int enrol, double marks, int age)	
	{
		System.out.println("\n\n******************\nData of Student 1: ");
		System.out.println("Name: " +name+ "\nEnrolment Number: " +enrol+ "\nPercentage: " +marks+ "\nAge: "+age);
	}
}

class Student2
{
	void displayStudent(String name, int enrol, double marks, int age)	
	{
		System.out.println("\n******************\nData of Student 2: ");
		System.out.println("Name: " +name+ "\nEnrolment Number: " +enrol+ "\nPercentage: " +marks+ "\nAge: "+age);
	}
}
public class MethodOverriding
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program implements Method Overriding");
		System.out.println("\nEnter the data for Student 1: ");			//getting data for student 1
		System.out.print("Enter name: ");
		String s1Name = sc.nextLine();
		System.out.print("Enter enrolment: ");
		int s1Enrol = sc.nextInt();
		System.out.print("Enter percentage: ");
		double s1Marks = sc.nextDouble();
		System.out.print("Enter age: ");
		int s1Age = sc.nextInt();
		sc.nextLine();			
		Student1 myStud1 = new Student1();
		
		
		System.out.println("\n\nEnter the data for Student 2: ");
		System.out.print("Enter name: ");					//getting data for student 2
		String s2Name = sc.nextLine();
		System.out.print("Enter enrolment: ");
		int s2Enrol = sc.nextInt();
		System.out.print("Enter percentage: ");
		double s2Marks = sc.nextDouble();
		System.out.print("Enter age: ");
		Student2 myStud2 = new Student2();
		int s2Age = sc.nextInt();
		
		myStud1.displayStudent(s1Name, s1Enrol, s1Marks, s1Age);		//calling method for displaying the data using myStud1
		myStud2.displayStudent(s2Name, s2Enrol, s2Marks, s2Age);		//calling method for displaying the data using myStud2
	}
}