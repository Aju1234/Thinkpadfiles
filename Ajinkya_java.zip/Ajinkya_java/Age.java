import java.util.*;

public class Age
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will find your age from entered DoB: ");
		System.out.println();
		int ans = 1;
		do
		{
			System.out.print("\nEnter the date(DD): ");
			int date = sc.nextInt(); 	//getting the date
			System.out.print("\nEnter the month(MM): ");
			int month = sc.nextInt();	//getting the month	
			System.out.print("\nEnter the year(YYYY): ");
			int year = sc.nextInt();	//getting the year
			int currentYear = 2021, currentMonth = 9;
			int ageInYear = currentYear - year;		
			int ageInMonth = currentMonth - month;
			System.out.println();
			System.out.println("Your DoB: " +date+ "/" +month+ "/" +year);
			System.out.println("Your age: "+ageInYear+ " yr and "+ageInMonth+" month");	
			System.out.print("\nDo you want to continue(0/1)? ");
			ans = sc.nextInt();
		}while(ans == 1);

	}
}