import java.util.*;

class Employee
{
	String name, gender;
	int age;
	public void empDetails()
	{
		Scanner sc = new Scanner(System.in);	
		System.out.println("Enter the employee details: ");
		System.out.print("\nEnter name: ");
		name = sc.nextLine();
		System.out.print("Enter gender: ");
		gender = sc.nextLine();
		System.out.print("Enter your age: ");	
		age = sc.nextInt();
		sc.nextLine();
	}
	void displayEmp()
	{
		System.out.println("\n\n********************\nDisplaying the entered details: ");
		System.out.println("\nName: " +name+ "\nAge: " +age+ "\nGender: "+gender);	
	}
}

class Engineer extends Employee
{
	String field;
	int subjects, semesters;
	public void engineerDetails()
	{
		Scanner sc = new Scanner(System.in);	
		System.out.print("Enter field/course: ");
		field = sc.nextLine();
		System.out.print("Enter total subjects: ");
		subjects = sc.nextInt();
		System.out.print("Enter no of semesters: ");	
		semesters = sc.nextInt();
		sc.nextLine();
	}
	void displayEngineer()
	{
		System.out.println("Engineering Field: " +field+ "\nTotal subjects: " +subjects+ "\nTotal semesters: "+semesters);	
	}
	
}

class SoftwareEngineer extends Engineer
{
	int duration, salary, exp;
	float cgpa;
	String org;
	public void softwareEngineerDetails()
	{
		Scanner sc = new Scanner(System.in);	
		empDetails();
		engineerDetails();	
		System.out.print("Enter course duration (in years): ");
		duration = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter acquired CGPA's: ");	
		cgpa = sc.nextFloat();
		sc.nextLine();
		System.out.print("Enter current organization: ");
		org = sc.nextLine();
		System.out.print("Enter salary: ");
		salary = sc.nextInt();
		System.out.print("Enter experience (in years): ");	
		exp = sc.nextInt();
		sc.nextLine();
	}
	void displaySoftwareEngineer()
	{
		displayEmp();
		displayEngineer();
		System.out.print("Course Duration: " +duration+ "\nAcquired CGPA: " +cgpa+ "\nCurrently working in: " +org+ "\nSalary: " +salary+ "\nExperience(in years): "+exp);	
	}
}


public class MultilevelInheritance
{
	public static void main(String arg[])
	{
		System.out.println("This program is implementing Multilevel Inheritance.");
		SoftwareEngineer myEmp = new SoftwareEngineer();
		myEmp.softwareEngineerDetails();
		myEmp.displaySoftwareEngineer();
		System.out.println("\n********************\n");
	}
}
