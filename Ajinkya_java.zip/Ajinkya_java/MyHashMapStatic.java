import java.util.*;

public class MyHashMapStatic
{
	public static void main(String args[])
	{
		//Scanner sc = new Scanner(System.in);
		HashMap<String, Integer> myMap = new HashMap<String, Integer>();
		myMap.put("Ajinkya", 1906129);
		myMap.put("Prathamesh", 1906131);
		myMap.put("Siddhesh", 1906119);
		myMap.put("Somesh", 1906124);
		System.out.println("Size of your hashmap is: "+myMap.size());
		System.out.println(myMap);
		
	}
}