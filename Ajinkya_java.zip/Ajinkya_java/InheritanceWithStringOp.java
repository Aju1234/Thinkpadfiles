import java.util.*;

class AcceptString
{	
	public String str1, str2;
	Scanner sc = new Scanner(System.in);	
	void getStrings()
	{	
		System.out.print("\nEnter your first string: ");
		str1 = sc.nextLine();					//getting str1		
		System.out.print("Enter your second string: ");
		str2 = sc.nextLine();					//getting str2
	}
}

class StringOperation extends AcceptString
{
	void concatenation()
	{
		System.out.println("\n-> Concatenation of "+str1+ " and "+str2+ " is " +str1.concat(str2));
	}
	
	void upperCase()
	{
		System.out.print("\n ->" +str1+ " after applying toUpperCase() is: "+str1.toUpperCase());
	}
	void lowerCase()
	{
		System.out.print("\n ->" +str1+ " after applying toUpperCase() is: "+str1.toLowerCase());
	}
	void findLength()
	{
		System.out.print("\n -> Length of "+str1+ " is :"+str1.length());
	}
}

class DisplayOperation extends StringOperation 
{
	void display()
	{
		//System.out.println("\n-> Concatenation of "+str1+ " and "+str2+ " is " +str1.concat(str2));
		concatenation();
		upperCase();
		lowerCase();
		findLength();
	}	
}

public class InheritanceWithStringOp
{
	public static void main(String args[])
	{
		//Scanner sc = new Scanner(System.in);
		DisplayOperation myObj = new DisplayOperation();
		myObj.getStrings();
		myObj.display();
		
	}
}	

