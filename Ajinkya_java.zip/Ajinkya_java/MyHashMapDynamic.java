import java.util.*;

public class MyHashMapDynamic
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
        HashMap<String, Integer> myMap = new HashMap<String, Integer>();
        System.out.println("This program is about HashMap");
        System.out.print("\nEnter how many key-value pairs you want in HashMap: ");
        int no = sc.nextInt();
        
        //getting the values for HashMap
        for(int i=1; i<=no; i++)
        {
            System.out.print("---------------------------------------");
            System.out.print("\nEnter the key for key-value pair number " +i+ " : ");
            String name = sc.next();
            sc.nextLine();
            System.out.print("Enter the value for key-value pair number " +i+ " : ");
            int enrol = sc.nextInt();
            myMap.put(name, enrol);
        }
        
        //displaying size of hashmap
		System.out.println("\n\nSize of your hashmap is: "+myMap.size());
		//disolaying hashmap
		System.out.println(myMap);
		
	}
}
