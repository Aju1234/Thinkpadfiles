import java.util.*;

class Employee
{
	String name, designation, joinDate, pastOrg;	
	int id, salary,experience;
	
	Employee(String name, int id, int salary)	//Defining the contructor explicitly which will hide/disappear the default constuctor
	{
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
		
	Employee(String name, int id, int salary, String designation, int experience, String joinDate, String pastOrg)
	{
		this(name,id,salary);
		this.designation = designation;
		this.experience = experience;
		this.joinDate = joinDate;
		this.pastOrg = pastOrg;
	}
	void displayEmployee()							//To display the generic data
	{
		System.out.println(" Id -> " +id+ "\n Name -> "+name+ "\n Salary -> "+salary);
		if(designation != null)
			displayOther();
	}
	void displayOther()
	{

		System.out.println(" Designation -> " +designation+ "\n Experience -> "+experience+ "\n Joining Date -> "+joinDate+ "\n Past Organization -> "+pastOrg);				
	}
}

public class MultipleParametarizedConstructor
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the details of Security Gaurd: ");
		System.out.print("\nEnter gaurd's name: ");
		String gName = sc.nextLine();	
		System.out.print("Enter gaurd's ID: ");
		int gId = sc.nextInt();
		System.out.print("Enter gaurd's salary: ");
		int gSalary = sc.nextInt();	
		sc.nextLine();	
		Employee gaurd = new Employee(gName, gId, gSalary);		//Calling the constructor at the time of obj creation
		System.out.println("\n Gaurd Detais: ");	
		gaurd.displayEmployee();
		
		System.out.println("\n--------------------------------------------");
		System.out.println("Enter the details of other employee: ");
		System.out.print("\nEnter employee's name: ");
		String eName = sc.nextLine();	
		System.out.print("Enter employee's ID: ");
		int eId = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter employee's salary: ");
		int eSalary = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter employee's designation: ");
		String eDesignation= sc.nextLine();	
		System.out.print("Experience (in yrs): ");
		int eExperience = sc.nextInt();
		sc.nextLine();
		System.out.print("Enter employee's joining date: ");
		String eJoining = sc.nextLine();	
		System.out.print("Enter employee's previous organization: ");
		String eLastOrg	 = sc.nextLine();		
		Employee emp = new Employee(eName, eId, eSalary, eDesignation, eExperience, eJoining, eLastOrg);		//Calling the constructor at the time of obj creation
		System.out.println("\n "+eDesignation+" Details: ");
		emp.displayEmployee();		
	}
}