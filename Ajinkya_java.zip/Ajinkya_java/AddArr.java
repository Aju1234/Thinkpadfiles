import java.util.*;

public class AddArr
{	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int arr[], size, i, respo = 0;
		long add=0;
		System.out.print(" This program will add all the elements in an array.");
		do
		{
			add = 0;
			System.out.print("\n Enter the size of array: ");
			size = sc.nextInt();
			arr = new int[size];
			for(i=0; i<size; i++)
			{
				System.out.print("\n Enter the number for index "+i+": ");
				arr[i] = sc.nextInt();
			}
			System.out.print("\n Your array is: ");
			for(i=0; i<size; i++)
			{
				System.out.print(" "+arr[i]);
			}
			for(i=0; i<size; i++)
			{
				add = add + arr[i];
			}
			System.out.print("\n Addition of all the elements of given array is: "+add);
			System.out.print("\n Do you want to continue(1/0)? ");
			respo = sc.nextInt();
		}while(respo == 1);
	}
}