import java.util.*;
import java.lang.*;

public class StringFunctions
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will perform the string operations on given string.");
		int respo = 1;
		System.out.print("\nEnter your first string: ");
		String str1 = sc.nextLine();					//getting str1
		System.out.print("\nEnter your second string: ");
		String str2 = sc.nextLine();					//getting str2
		do
		{
			System.out.println("You can do following operations on the entered strings: ");
			System.out.print("1.Concatenation  |  2.Comaprison  |  3.Substring  |  4.toUpperCase  |  5.toLowerCase  |  6.trim  |  7.charAt  |  8.startsWith  |  9.endsWith  |  10.length  |  11.replace");
			System.out.print("\n\nEnter the task you want to perform: ");
			int task = sc.nextInt();
			switch(task)
			{
				case 1:						//Concatenation
					System.out.println("\n-> Concatenation of "+str1+ " and "+str2+ " is " +str1.concat(str2));
				break;

				case 2:						//Comparison
					if(str1.equals(str2))
						System.out.println("\n-> Using equals method(case sensitively) " +str1+ " and " +str2+ " both are same.");
					if(str1.equalsIgnoreCase(str2))
						System.out.println("\n-> Using equalsIgnoreCase method(ignoring case sensitivity) " +str1+ " and " +str2+ " both are same.");
				break;

				case 3:						//substring
					System.out.print("Enter how many characters you want to remove from '"+str1+ "' (less than " +str1.length()+ "): ");
					int cut = sc.nextInt();
					System.out.print("\n-> " +str1+ " after removing first "+cut+ " characters is: "+str1.substring(cut));
				break;
				
				case 4:						//toUpperCase
					System.out.print("\n ->" +str1+ " after applying toUpperCase() is: "+str1.toUpperCase());
				break;
					
				case 5:						//toLowerCase
					System.out.print("\n ->" +str2+ " after applying toLowerCase() is: "+str2.toLowerCase());
				break;
					
				case 6:						//trim
					System.out.print("\n ->"+str1+ " after applying trim() is: "+str1.trim());
				break;
	
				case 7:						//charAt
					System.out.print("Enter the index on which you want to find the char: ");
					int index = sc.nextInt();
					System.out.print("\n -> Char at index " +index+" in "+str1+" is : "+str1.charAt(index));
				break;

				case 8:						//startsWith
					System.out.print("Enter the characters to check whether the string starts with it or not: ");
					String sampleStart = sc.next();
					sc.nextLine();
					if(str1.startsWith(sampleStart))
						System.out.print("\n -> String do start with "+sampleStart);
					else
						System.out.print("\n -> String does not start with "+sampleStart);	
				break;

				case 9:						//endsWith
					System.out.print("Enter the characters to check whether the string starts with it or not: ");
					String sampleEnd = sc.next();
					sc.nextLine();
					if(str1.endsWith(sampleEnd))
						System.out.print("\n -> String do ends with "+sampleEnd);
					else
						System.out.print("\n -> String does not end with "+sampleEnd);	
				break;	
				
				case 10:					//length
					System.out.print("\n -> Length of "+str1+ " is :"+str1.length());
				break;
				
				case 11:					//replace
					String s1 ="College is in Pune. College is located near SPPU";
					System.out.print("String is: " +s1);
					String s2 =s1.replace("College", "Gpp");
					System.out.print("\n -> After applying replace method string is: "+s2);
				break;

				default:
					System.out.println("Invalid choice please try again!!");
			}			
			System.out.print("\nDo you want to continue(1/0)? ");
			respo = sc.nextInt();
			sc.nextLine();
		}while(respo == 1);

	}
}