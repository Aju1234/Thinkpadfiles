import java.util.*;
public class MagicSquare
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of array(must be odd): ");
		int size = sc.nextInt();
		int arr[][] = new int[size][size];
		System.out.print("Enter any number to start with: ");
		int no = sc.nextInt();
		/*int i = 0, j = size/2, cnt = 1;
		arr[i][j] = no;
		while(cnt < (size * size))*/
		for(int i = 0, j = size/2, cnt = 1; cnt <= (size * size); i--, j++)
		{
			/*i--;
			j++;*/
			//System.out.println("i= " + i + " j= " + j);
			
			if(i == -1 && j == size)
			{
				i+=2;
				j--;
			}
			else if(i == -1)
				i = size - 1;
			else if(j == size)
				j = 0;
			else if(arr[i][j] != 0)
			{
				i+=2;
				j--;
			}
	
			arr[i][j] = no++;
			cnt++;
		}
		
		System.out.println("\nMagic Sqaure is as follow:\n ");
		
		for(int i=0; i<size; i++)
		{
			for(int j=0; j<size; j++)
			{
				System.out.print(" "+arr[i][j]+ " ");
			}
			System.out.println("\n");
		}
		
	}
}
