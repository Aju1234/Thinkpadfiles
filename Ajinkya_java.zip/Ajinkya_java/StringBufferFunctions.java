import java.util.*;
import java.lang.*;

public class StringBufferFunctions
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will perform functions provided by StringBuffer class.");
		int respo = 1;
		do
		{
			System.out.print("\nEnter your first string: ");
			StringBuffer str1 = new StringBuffer();				//getting str1
			str1.append(sc.nextLine());
			System.out.println("You can do following operations on the entered strings: ");
			System.out.print("1.Append  |  2.Insert  |  3.Replace |  4.Delete  |  5.Reverse");
			System.out.print("\n\nEnter the task you want to perform: ");
			int task = sc.nextInt();
			sc.nextLine();
			switch(task)
			{
				case 1:							//appending
					System.out.print("Enter the string you want to append: ");
					String str2 = sc.nextLine();
					System.out.print("-> "+str1+ " after appending with "+str2+ " is : " +str1.append(str2));
				break;

				case 2:							//inserting
					System.out.print("Enter the index at which you want to insert: ");
					int index = sc.nextInt();
					sc.nextLine();
					System.out.print("\nEnter the string you want to insert: ");
					String insertStr = sc.nextLine();
					System.out.print("-> "+str1+ " after inserting "+insertStr+ " at index "+index+" is : " +str1.insert(index, insertStr));
				break;

				case 3:							//Replacing the part of the string
					System.out.print("Enter the starting index from where you want to replace: ");
					int indexStart = sc.nextInt();
					System.out.print("Enter the ending index till where you want to replace: ");
					int indexEnd = sc.nextInt();
					sc.nextLine();
					System.out.print("\nEnter the string you want to replace with: ");
					String replaceStr = sc.nextLine();
					System.out.print("-> Final String is: "+str1.replace(indexStart, indexEnd, replaceStr));
				break;
				
				case 4:							//deleting the part of the string
					System.out.print("Enter the starting index from where you want to delete: ");
					int deleteIndexStart = sc.nextInt();
					System.out.print("Enter the ending index till where you want to delete: ");
					int deleteIndexEnd = sc.nextInt();
					sc.nextLine();
					System.out.print("-> Final String is: "+str1.delete(deleteIndexStart, deleteIndexEnd));
				break;
					
				case 5:							//revering the string
					System.out.print("-> Reverse of " +str1+ " is :"+str1.reverse());
				break;
				
				default:
					System.out.println("Invalid choice please try again!!");
			}			
			System.out.print("\nDo you want to continue(1/0)? ");
			respo = sc.nextInt();
			sc.nextLine();
		}while(respo == 1);
	}
}