import java.util.*;

public class Fibonacci
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will generate the Fibonacci Series.");
		int ans = 1;
		do	
		{
			int no1 = 0, no2 = 1, no3;
			System.out.print("\nEnter how many numbers you want in the series:  ");
			int limit = sc.nextInt();
			System.out.print("Fibonacci Series: ");
			System.out.print(no1+ " " +no2);
			for(int i = 1; i < limit-1; i++)
			{
				no3 = no1 + no2;
				System.out.print(" "+no3);
				no1 = no2;
				no2 = no3;
			}
			System.out.print("\n\nDo you want to continue(0/1)? ");
			ans = sc.nextInt();
		}while(ans ==1);
	}
}
