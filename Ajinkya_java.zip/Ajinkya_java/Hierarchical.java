import java.util.*;

class Parent
{
	String status;
	void getstatus()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("\nEnter your status: ");
		status = sc.nextLine();
	}
}
class Child1 extends Parent
{
	/*void child1Status()
	{
		System.out.println("In child1 class");
		getstatus();
	}*/
}

class Child2 extends Parent
{
	/*void child2Status()
	{
		System.out.println("In child2 class");
		getstatus();
	}*/
}

public class Hierarchical
{
	public static void main(String args[])
	{
		Child1 myObj1 = new Child1();
		System.out.println("from parent class");
		myObj1.getstatus();
		myObj1.getstatus();
		Child2 myObj2 = new Child2();
		myObj2.getstatus();
	}
}