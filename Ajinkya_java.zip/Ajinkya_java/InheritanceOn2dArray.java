import java.util.*;
	
class Acceptance
{
		Scanner sc = new Scanner(System.in);
		public int size;
		public int [][]arr1, arr2;
		void acceptance()
		{
			System.out.print("\nEnter number of rows and columns your matrices should have: ");
			size = sc.nextInt();
			System.out.println("\nEnter the value for your first matrix: ");		//taking first matrix
			arr1 = new int[size][size];
			for(int i = 0; i < size; i++)							//for loop for columns
			{
				for(int j = 0; j < size; j++)						//for loop for rows
				{
					System.out.print("Enter the element for index ["+i+"]["+j+"] : ");
					arr1[i][j] = sc.nextInt();					//accepting the element
				}
			}
			System.out.println("\nEnter the value for your second matrix: ");		//taking second matrix
			arr2 = new int[size][size];
			for(int p = 0; p < size; p++)							//for loop for columns
			{
				for(int q = 0; q < size; q++)						//for loop for rows
				{
					System.out.print("Enter the element for index ["+p+"]["+q+"] : ");
					arr2[p][q] = sc.nextInt();					//accepting the element
				}		
			}
		}
}

class Addition extends Acceptance
{	
	//Scanner sc = new Scanner(System.in);
	void addition()
	{
		System.out.println("\nFinal matrix after addition of given matrices is:");
		int resAdd[][] = new int[size][size];
		//System.out.print("wewe");
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				System.out.print((resAdd[i][j] = arr1[i][j] + arr2[i][j]) +" e");
			}
		System.out.print("\n");
		}	
	}
}
class Multiplication extends Acceptance
{
	Scanner sc = new Scanner(System.in);
	void multiplication()
	{
		System.out.println("\nFinal matrix after multiplication of given matrices is:");
		int resMul[][] = new int[size][size];
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{	
				for(int a = 0; a < size; a++)
				{
					resMul[i][j] = resMul[i][j] + (arr1[i][a] * arr2[a][j]);		
				}
				System.out.print(resMul[i][j] +" ");
			}
			System.out.print("\n");
		}
	}
}
public class InheritanceOn2dArray
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("\nThis program is about Matrix Operations.");
		Multiplication myMulObj = new Multiplication();
		myMulObj.acceptance();	
		Addition myAddObj = new Addition();
		myAddObj.addition();
		myMulObj.multiplication();
	}
}

