public class Operator
{
	public static void main(String args[])
	{
		/*long x= 10, y=66;
		byte z= x + y;
		System.out.print(x>>>y);
		System.out.print(10>>35);*/
		if(true)
		{
			int a=10;
		}
	}
}