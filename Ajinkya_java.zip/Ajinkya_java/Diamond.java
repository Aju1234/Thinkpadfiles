import java.util.*;

public class Diamond
{
	public static void main(String args[])
	{	
		Scanner sc = new Scanner(System.in);
		System.out.println("This program will print Right Hand Right Angled Triangle.");
		System.out.print("\nEnter the maximum star you want in a row: ");
		int star = sc.nextInt();
		for(int i=0; i<=star; i++)	//for next line
		{
			for(int j=i; j<star; j++)	//for space
				System.out.print(" ");

			for(int k=i; k>0; k--)	//for printing stars
			{
				System.out.print(" *");
			}
		System.out.println();
		}

		//reversing the diamonf
		for(int i=star-1; i>=0; i--)	//for next line
		{
			for(int j=i; j<star; j++)	//for space
				System.out.print(" ");

			for(int k=i; k>0; k--)	//for printing stars
			{
				System.out.print(" *");
			}
		System.out.println();
		}
	}
}