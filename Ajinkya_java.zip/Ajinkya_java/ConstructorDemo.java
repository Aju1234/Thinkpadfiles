import java.util.*;

class Employee
{
	int id;
	String name;
	Employee(int i, String s)	
	{
		id = i;
		name = s;
	}
	void display()
	{
		System.out.println("\nId= " +id+ " Name= "+name);
	}
}
public class ConstructorDemo
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("\nEnter ID: ");
		int i = sc.nextInt();
		sc.nextLine();
		System.out.print("\nEnter name: ");
		String s = sc.nextLine();
		Employee e1 = new Employee(i, s);
		e1.display();	
	}
}