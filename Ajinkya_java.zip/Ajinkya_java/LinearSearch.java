import java.util.*;

public class LinearSearch
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int arr[], size, i, find, respo = 0;
		boolean flag;
		System.out.print("\n This program will do linear searching of an element in an array.");
		System.out.print("\n Enter the size of array: ");
		size = sc.nextInt();
		arr = new int[size];
		for(i=0; i<size; i++)
		{
			System.out.print("\n Enter the value for index "+i+" : ");	
			arr[i] = sc.nextInt();
		}
		System.out.print("\n Your array is: ");
		for(i=0; i<size; i++)
		System.out.print(" " +arr[i]);
		do
		{
			flag = false;	
			System.out.print("\n Enter the number you want search: ");
			find = sc.nextInt();	
			for(i=0; i<size; i++)
			{
				if(arr[i] == find)
				{
					flag = true;	
					break;
				}
					
			}
			if(flag)
				System.out.print("\n The number you are looking for is at index "+i+ ".");
			else
				System.out.print("\n Number not found in given array.");
			System.out.print("\n Do you want to continue(1/0)? ");
			respo = sc.nextInt();
		}while(respo == 1);	
	}
}
